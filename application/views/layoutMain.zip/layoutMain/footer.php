 <footer>
	<div class="container">
		<div class="row">
			<div class="col-sm-3 foo">
				<a href="#">2015, Cimalis    &copy;</a>
			</div>
			<div class="col-sm-3 foo"><a href="#">CGV</a></div>
			<div class="col-sm-3 foo"><a href="contact.php">Contact</a></div>
			<div class="col-sm-3 foo tar"> <a href="userInterface.php">Mentions legales</a></div>
		</div>
	</div>
</footer>
	


<script type="text/javascript" src="/assets/FrontEnd/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/assets/FrontEnd/js/navigation.js"></script>
<script type="text/javascript" src="/assets/FrontEnd/js/skip-link-focus-fix.js"></script>
<script type="text/javascript" src="/assets/FrontEnd/js/main.js"></script>

 </body>
 </html>