
/*var myApp = angular.module('myApp', []);

// listing data with search
myApp.controller('ProductListCtrl', function ($scope,$http) {

    var $url =  "<?php base_url('')?>/Products/index"

  $http.post($url).success(function(data) {
      $scope.products = data
   });
});*/



