<div class="row" >
    <div class="col-md-12">

        <div class="col-md-11">

            <div class="portlet-body form">
                <form action="/Categories/save" method="post">
                <div class="form-body">

                    <div class="form-group">
                        <label>Category Name</label>
                        <div class="input-group">
											<span class="input-group-addon input-circle-left">
											<i class="fa fa-envelope"></i>
											</span>
                            <input name="name" class="form-control" placeholder="Category Name" type="text"/>

                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn default">Save</button>
                    </div>

                </div>
                </form>
            </div>

        </div>
    </div>
</div>