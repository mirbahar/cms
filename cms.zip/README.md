# cms
E commerce Site

step1: At first download this project  then extract this project

step2: configure database

step3: create virtual host like (www.cms.dev)

admin login credential

email : admin@admin.com
password : password

Frontend Url : your created virtual host
BackEnd Url : auth/login
